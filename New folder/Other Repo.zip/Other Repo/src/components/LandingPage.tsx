import React from 'react';
import AlgopayLandingPage from './AlgopayLandingPage';



export const LandingPage = () => {
  return (
    <AlgopayLandingPage />
  );
};