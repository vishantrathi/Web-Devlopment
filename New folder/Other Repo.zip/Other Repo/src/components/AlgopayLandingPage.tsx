import { Button } from "../ui/components/Button";
// import { IconWithBackground } from "../ui/components/IconWithBackground";
import EnhancedNavbar from "../ui/components/EnhancedNavbar";
import EnhancedFooter from "../ui/components/EnhancedFooter";
import Squares from "./Squares";
import {
  Clock,
  DollarSign,
  Globe,
  Shield,
  Bot,
  Wallet,
  ArrowRight
} from 'lucide-react';
// import { Bolt } from './Icons'
function AlgopayLandingPage() {
  return (
    <div className="flex h-full w-full flex-col items-start bg-default-background">
      {/* Navigation - Fixed position navbar */}
      <EnhancedNavbar transparent={true} />

      {/* Hero Section - First visible section with padding for navbar */}
      <div id="home" className="flex w-full flex-col items-center justify-center gap-12 b px-6 py-32 pt-40 relative overflow-hidden">
        {/* Squares Background */}
        <Squares
          speed={0.5}
          squareSize={40}
          direction='diagonal'
          borderColor="#f1f1f1"
          hoverFillColor="#F1F1F1"
        />

        {/* Animated Gradient Overlay */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-transparent via-brand-50/10 to-transparent animate-pulse-slow z-0"></div>

        {/* Content */}
        <div className="flex w-full flex-col items-center justify-center gap-8 z-10">
          <div className="inline-block px-4 py-2 bg-brand-50 rounded-full mb-2">
            <span className="font-['Montserrat'] text-[14px] font-[700] text-brand-800">EXPERT DIGITAL FORENSICS</span>
          </div>
         <span className="w-full max-w-[1024px] text-balance break-words font-['Montserrat'] text-[clamp(32px,6vw,96px)] font-[900] leading-tight text-brand-800 text-center">

            {"Uncover the Truth"} <br /> <span className="bg-gradient-to-r from-brand-800 to-brand-600 bg-clip-text text-transparent">with Expert Digital Forensics</span>
          </span>

          <span className="w-full max-w-[768px] whitespace-pre-wrap font-['Montserrat'] text-[22px] font-[600] leading-[32px] text-brand-800 text-center -tracking-[0.015em]">
            {
              "We specialize in digital forensics and cyber fraud investigation. Our team uses cutting-edge technology and innovative methods to uncover the truth in complex cases."
            }
          </span>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-6 z-10">
          <Button
            size="large"
            variant="neutral-secondary"
            onClick={() => document.getElementById('features-section')?.scrollIntoView({ behavior: 'smooth' })}
            icon={<ArrowRight size={20} />}
            className="px-8 py-6 hover:bg-brand-50 transition-all duration-300"
          >
            Learn More
          </Button>
        </div>

        {/* Stats Bar */}
        <div className="flex flex-wrap justify-center gap-12 mt-12 z-10 w-full max-w-[1024px]">
          <div className="flex flex-col items-center">
            <span className="font-['Montserrat'] text-[36px] font-[900] text-brand-800">24/7</span>
            <span className="font-['Montserrat'] text-[14px] font-[600] text-brand-600">Support Available</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-['Montserrat'] text-[36px] font-[900] text-brand-800">100%</span>
            <span className="font-['Montserrat'] text-[14px] font-[600] text-brand-600">Confidentiality</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-['Montserrat'] text-[36px] font-[900] text-brand-800">Expert</span>
            <span className="font-['Montserrat'] text-[14px] font-[600] text-brand-600">Certified Professionals</span>
          </div>
        </div>
      </div>

      {/* Core Components Section */}
      <div id="features-section" className="flex w-full flex-col items-center justify-center gap-16 bg-neutral-100 px-6 py-32">
        <div className="flex w-full max-w-[1280px] flex-col items-center gap-4">
          <span className="inline-block px-4 py-1 bg-brand-50 rounded-full mb-2">
            <span className="font-['Montserrat'] text-[12px] font-[700] text-brand-800">OUR SERVICES</span>
          </span>
          <span className="w-full font-['Montserrat'] text-[48px] font-[800] leading-[52px] text-default-font text-center -tracking-[0.02em]">
            Comprehensive Forensic Services
          </span>
          <p className="max-w-[768px] text-center text-subtext-color font-['Montserrat'] text-[18px] leading-[28px]">
            We specialize in investigating complex digital crimes such as cybercrime, intellectual property theft, and financial fraud
          </p>
        </div>

        <div className="w-full max-w-[1280px] grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Audio Video Analysis */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col gap-6">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center">
                <Bot size={24} className="text-brand-800" />
              </div>
              <h3 className="font-['Montserrat'] text-[24px] font-[700]">Audio Video Analysis</h3>
            </div>
            <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px]">
              Audio and video are digital sources of evidence that can be found at the scene of a crime or with the victim or the accused.
            </p>
            <div className="flex flex-wrap gap-2 mt-auto">
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Evidence Recovery</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Expert Analysis</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Court Admissible</span>
            </div>
            <div className="flex items-center gap-4 mt-4">
              <Shield size={20} className="text-brand-800" />
              <span className="font-['Montserrat'] text-[14px] font-[500] leading-[20px] text-default-font">Certified Experts</span>
            </div>
          </div>

          {/* Cloud Forensics */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col gap-6">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center">
                <Globe size={24} className="text-brand-800" />
              </div>
              <h3 className="font-['Montserrat'] text-[24px] font-[700]">Cloud Forensics</h3>
            </div>
            <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px]">
              Cloud forensics allows users to conveniently access fully featured applications and development environments for forensic analysis.
            </p>
            <div className="flex flex-wrap gap-2 mt-auto">
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Cloud Investigation</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Data Recovery</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Secure Access</span>
            </div>
            <div className="flex items-center gap-4 mt-4">
              <Globe size={20} className="text-brand-800" />
              <span className="font-['Montserrat'] text-[14px] font-[500] leading-[20px] text-default-font">Advanced Tools</span>
            </div>
          </div>

          {/* Computer Forensics */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col gap-6">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center">
                <Shield size={24} className="text-brand-800" />
              </div>
              <h3 className="font-['Montserrat'] text-[24px] font-[700]">Computer / MAC Forensic</h3>
            </div>
            <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px]">
              Computer forensics is a scientific method of investigation and examination to gather evidence from digital devices or computer networks.
            </p>
            <div className="flex flex-wrap gap-2 mt-auto">
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Evidence Collection</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Analysis</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Reporting</span>
            </div>
            <div className="flex items-center gap-4 mt-4">
              <Shield size={20} className="text-brand-800" />
              <span className="font-['Montserrat'] text-[14px] font-[500] leading-[20px] text-default-font">Scientific Methods</span>
            </div>
          </div>

          {/* Cyber Fraud Investigation */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col gap-6">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-12 h-12 rounded-full bg-brand-50 flex items-center justify-center">
                <Shield size={24} className="text-brand-800" />
              </div>
              <h3 className="font-['Montserrat'] text-[24px] font-[700]">Cyber Fraud Investigation</h3>
            </div>
            <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px]">
              Cybercrime refers to crimes committed using the internet or other types of computer networks, including hacking, identity theft, and more.
            </p>
            <div className="flex flex-wrap gap-2 mt-auto">
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Hacking</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Identity Theft</span>
              <span className="px-3 py-1 bg-brand-50 rounded-full text-sm font-medium text-brand-800">Fraud</span>
            </div>
            <div className="flex items-center gap-4 mt-4">
              <Shield size={20} className="text-brand-800" />
              <span className="font-['Montserrat'] text-[14px] font-[500] leading-[20px] text-default-font">Expert Investigation</span>
            </div>
          </div>
        </div>

        {/* Show More Button */}
        <div className="flex justify-center mt-8">
          <Button
            size="large"
            variant="brand-primary"
            onClick={() => document.getElementById('benefits-section')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4"
          >
            Show More
          </Button>
        </div>
      </div>

      {/* Articles Section */}
      {/* <div className="flex w-full flex-col items-center justify-center gap-12 bg-default-background px-6 py-32">
        <div className="flex w-full max-w-[1280px] flex-col items-center gap-8">
          <span className="inline-block px-4 py-1 bg-brand-50 rounded-full mb-2">
            <span className="font-['Montserrat'] text-[12px] font-[700] text-brand-800">INSIGHTS</span>
          </span>
          <span className="w-full font-['Montserrat'] text-[48px] font-[800] leading-[52px] text-default-font text-center -tracking-[0.02em]">
            Latest Articles from Enreach Solution
          </span>
        </div> */}

        {/* <div className="w-full max-w-[1280px] grid grid-cols-1 md:grid-cols-3 gap-8"> */}
          {/* Article 1 */}
          {/* <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
            <div className="h-48 bg-gradient-to-br from-brand-800 to-brand-600"></div>
            <div className="p-8">
              <h3 className="font-['Montserrat'] text-[22px] font-[700] mb-4 text-default-font group-hover:text-brand-800 transition-colors">
                Enreach Solution: The Cyber Forensic Authority in Delhi
              </h3>
              <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px] mb-6">
                Explore why Enreach Solution is Delhi's go-to name for all cyber forensic needs.
              </p>
              <Button
                size="medium"
                variant="neutral-secondary"
                icon={<ArrowRight size={16} />}
                className="group-hover:bg-brand-50"
              >
                Read More →
              </Button>
            </div>
          </div> */}

          {/* Article 2 */}
          {/* <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
            <div className="h-48 bg-gradient-to-br from-brand-700 to-brand-500"></div>
            <div className="p-8">
              <h3 className="font-['Montserrat'] text-[22px] font-[700] mb-4 text-default-font group-hover:text-brand-800 transition-colors">
                Cyber Threats in Delhi? Enreach Solution Has Your Back
              </h3>
              <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px] mb-6">
                Delhi faces rising cybercrime cases. Enreach Solution steps in with digital investigation expertise.
              </p>
              <Button
                size="medium"
                variant="neutral-secondary"
                icon={<ArrowRight size={16} />}
                className="group-hover:bg-brand-50"
              >
                Read More →
              </Button>
            </div>
          </div>*/}

          {/* Article 3 */}
         {/* <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
            <div className="h-48 bg-gradient-to-br from-brand-600 to-brand-400"></div>
            <div className="p-8">
              <h3 className="font-['Montserrat'] text-[22px] font-[700] mb-4 text-default-font group-hover:text-brand-800 transition-colors">
                Why Law Enforcement in Delhi Trusts Enreach Solution
              </h3>
              <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px] mb-6">
                Partnering with police and legal firms, Enreach Solution leads cyber forensic innovation.
              </p>
              <Button
                size="medium"
                variant="neutral-secondary"
                icon={<ArrowRight size={16} />}
                className="group-hover:bg-brand-50"
              >
                Read More →
              </Button>
            </div>
          </div>
        </div> */}

        {/* View All Articles Button */}
        {/*<div className="flex justify-center mt-8">
          <Button
            size="large"
            variant="brand-primary"
            className="px-8 py-4"
          >
            View All Articles
          </Button>
        </div>
      </div> */}

      {/* Key Benefits Section */}
      <div id="benefits-section" className="flex w-full flex-col items-center justify-center gap-16 bg-neutral-100 px-6 py-32 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        </div>

        <div className="flex w-full max-w-[1280px] flex-col items-center gap-6 z-10">
          <span className="inline-block px-4 py-1 bg-brand-50 rounded-full">
            <span className="font-['Montserrat'] text-[12px] font-[700] text-brand-800">WHY CHOOSE US</span>
          </span>
          <span className="w-full max-w-[768px] font-['Montserrat'] text-[48px] font-[800] leading-[52px] text-default-font text-center -tracking-[0.02em]">
            Expertise in Handling Complex Cyber Incidents
          </span>
          <p className="max-w-[768px] text-center text-subtext-color font-['Montserrat'] text-[18px] leading-[28px]">
            Our certified professionals deliver reliable, discreet, and timely results with accuracy, integrity, and professionalism in every investigation
          </p>
          
          {/* Why Choose Us List */}
          <div className="bg-white rounded-2xl p-8 shadow-lg max-w-[900px] w-full mt-6">
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-50 flex items-center justify-center mt-1 flex-shrink-0">
                  <span className="text-brand-800 text-sm font-bold">✓</span>
                </div>
                <span className="text-default-font font-['Montserrat'] text-[16px] leading-[24px]">Expertise in handling complex cyber incidents</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-50 flex items-center justify-center mt-1 flex-shrink-0">
                  <span className="text-brand-800 text-sm font-bold">✓</span>
                </div>
                <span className="text-default-font font-['Montserrat'] text-[16px] leading-[24px]">Certified and experienced professionals</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-50 flex items-center justify-center mt-1 flex-shrink-0">
                  <span className="text-brand-800 text-sm font-bold">✓</span>
                </div>
                <span className="text-default-font font-['Montserrat'] text-[16px] leading-[24px]">Proven track record of successful investigations</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-50 flex items-center justify-center mt-1 flex-shrink-0">
                  <span className="text-brand-800 text-sm font-bold">✓</span>
                </div>
                <span className="text-default-font font-['Montserrat'] text-[16px] leading-[24px]">Comprehensive services from data recovery to legal support</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-50 flex items-center justify-center mt-1 flex-shrink-0">
                  <span className="text-brand-800 text-sm font-bold">✓</span>
                </div>
                <span className="text-default-font font-['Montserrat'] text-[16px] leading-[24px]">Confidentiality and timely delivery guaranteed</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-brand-50 flex items-center justify-center mt-1 flex-shrink-0">
                  <span className="text-brand-800 text-sm font-bold">✓</span>
                </div>
                <span className="text-default-font font-['Montserrat'] text-[16px] leading-[24px]">24/7 support for urgent cases</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="w-full max-w-[1280px] flex flex-col gap-12 z-10">
          {/* Main Benefits Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* 4-Second Finality */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
              <div className="h-48 bg-brand-800 relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1620228885847-9eab2a1adddc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <Clock size={48} className="text-white" />
                  </div>
                </div>
              </div>

              <div className="p-8">
                <h3 className="font-['Montserrat'] text-[28px] font-[800] mb-4 text-default-font group-hover:text-brand-800 transition-colors">
                  Expert Investigation
                </h3>
                <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px] mb-6">
                  Comprehensive digital forensics services including data breaches, malware analysis, insider threats, and digital espionage investigations.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Court-admissible forensic reports</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Trace digital footprints and hidden evidence</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Work with law enforcement and legal professionals</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Ultra-Low Fees */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
              <div className="h-48 bg-brand-800 relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1526304760382-3591d3840148?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <DollarSign size={48} className="text-white" />
                  </div>
                </div>
              </div>

              <div className="p-8">
                <h3 className="font-['Montserrat'] text-[28px] font-[800] mb-4 text-default-font group-hover:text-brand-800 transition-colors">
                  Certified Professionals
                </h3>
                <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px] mb-6">
                  Our team of certified experts with proven track record of successful investigations ensures reliable and professional results.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Industry-certified forensic specialists</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Cutting-edge tools and methodologies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Continuous professional development</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* AI Intelligence */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group">
              <div className="h-48 bg-brand-800 relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1677442135968-8d288c3b6014?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <Bot size={48} className="text-white" />
                  </div>
                </div>
              </div>

              <div className="p-8">
                <h3 className="font-['Montserrat'] text-[28px] font-[800] mb-4 text-default-font group-hover:text-brand-800 transition-colors">
                  Comprehensive Services
                </h3>
                <p className="text-subtext-color font-['Montserrat'] text-[16px] leading-[24px] mb-6">
                  From data recovery to legal support, we provide end-to-end forensic investigation services tailored to your specific needs.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Data recovery and analysis services</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">Legal support and expert testimony</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center mt-1">
                      <span className="text-green-700 text-xs">✓</span>
                    </div>
                    <span className="text-default-font">24/7 support for urgent cases</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Additional Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-lg transition-all duration-300 flex items-center gap-6">
              <div className="w-16 h-16 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0">
                <Shield size={32} className="text-brand-800" />
              </div>
              <div>
                <h3 className="font-['Montserrat'] text-[20px] font-[700] mb-2">Confidentiality & Security</h3>
                <p className="text-subtext-color">Client confidentiality is our top priority with the highest standards of data security throughout the process</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-lg transition-all duration-300 flex items-center gap-6">
              <div className="w-16 h-16 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0">
                <Clock size={32} className="text-brand-800" />
              </div>
              <div>
                <h3 className="font-['Montserrat'] text-[20px] font-[700] mb-2">Timely Delivery</h3>
                <p className="text-subtext-color">We guarantee timely and professional results for all investigations with 24/7 support for urgent cases</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Use Cases Section */}
      <div className="flex w-full flex-col items-center justify-center gap-16 bg-default-background px-6 py-32">
        <div className="flex w-full max-w-[1280px] flex-col items-center gap-6">
          <span className="inline-block px-4 py-1 bg-brand-50 rounded-full">
            <span className="font-['Montserrat'] text-[12px] font-[700] text-brand-800">OUR SERVICES</span>
          </span>
          <span className="w-full max-w-[768px] font-['Montserrat'] text-[48px] font-[800] leading-[52px] text-brand-900 text-center -tracking-[0.02em]">
            Comprehensive Forensic Services
          </span>
          <p className="max-w-[768px] text-center text-subtext-color font-['Montserrat'] text-[18px] leading-[28px]">
            From audio video analysis to cyber fraud investigation, we provide comprehensive digital forensics services tailored to your specific needs
          </p>
        </div>

        <div className="w-full max-w-[1280px]">
          {/* Cybercrime Investigation Use Case */}
          <div className="flex flex-col md:flex-row bg-white rounded-3xl overflow-hidden shadow-xl mb-12">
            <div className="md:w-1/2 bg-brand-900 p-12 relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-700 rounded-bl-full opacity-50"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-brand-800 rounded-tr-full opacity-30"></div>

              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full mb-6">
                  <Shield size={16} className="text-white" />
                  <span className="font-['Montserrat'] text-[12px] font-[700] text-white">USE CASE 1</span>
                </div>

                <h2 className="font-['Montserrat'] text-[40px] font-[800] text-white mb-6">Cybercrime Investigation</h2>

                <p className="text-white/90 font-['Montserrat'] text-[18px] leading-[28px] mb-8">
                  We investigate complex digital crimes such as hacking, identity theft, and financial fraud using cutting-edge forensic tools and methodologies.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                    <h3 className="font-['Montserrat'] text-[18px] font-[700] text-white mb-2">For Corporations</h3>
                    <p className="text-white/80 text-sm">Protect your organization from insider threats, data breaches, and intellectual property theft with expert forensic investigation</p>
                  </div>

                  <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                    <h3 className="font-['Montserrat'] text-[18px] font-[700] text-white mb-2">For Law Enforcement</h3>
                    <p className="text-white/80 text-sm">Partner with certified experts to solve complex cybercrime cases with court-admissible evidence and reports</p>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-white/90">Court-admissible forensic reports</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-white/90">Advanced malware and threat analysis</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-white/90">Digital evidence recovery and preservation</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:w-1/2 p-8 md:p-12 flex flex-col">
              <div className="mb-8">
                <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">How It Works</h3>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-['Montserrat'] font-bold text-brand-800">1</span>
                    </div>
                    <div>
                      <h4 className="font-['Montserrat'] text-[18px] font-[600] text-default-font">Initial Assessment</h4>
                      <p className="text-subtext-color">Our team evaluates the incident scope, preserves digital evidence, and develops an investigation strategy.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-['Montserrat'] font-bold text-brand-800">2</span>
                    </div>
                    <div>
                      <h4 className="font-['Montserrat'] text-[18px] font-[600] text-default-font">Forensic Analysis</h4>
                      <p className="text-subtext-color">Using advanced tools, we extract and analyze digital evidence, trace digital footprints, and uncover hidden data.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-['Montserrat'] font-bold text-brand-800">3</span>
                    </div>
                    <div>
                      <h4 className="font-['Montserrat'] text-[18px] font-[600] text-default-font">Report Delivery</h4>
                      <p className="text-subtext-color">We provide comprehensive, court-admissible reports with findings, evidence chain of custody, and expert testimony if needed.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-auto">
                <div className="bg-neutral-50 rounded-xl p-6 border border-neutral-100">
                  <h4 className="font-['Montserrat'] text-[16px] font-[700] text-default-font mb-2">Real-World Example</h4>
                  <p className="text-subtext-color mb-4">
                    A Delhi-based corporation suspects an insider threat after detecting unauthorized data access. Our team conducts a complete forensic investigation, recovers deleted emails, traces network activity, and provides court-admissible evidence that helps prosecute the perpetrator.
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-green-50 rounded-full text-xs font-medium text-green-700">COURT ADMISSIBLE</span>
                    <span className="px-3 py-1 bg-green-50 rounded-full text-xs font-medium text-green-700">EXPERT TESTIMONY</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Data Breach Investigation Use Case */}
          <div className="flex flex-col md:flex-row-reverse bg-white rounded-3xl overflow-hidden shadow-xl">
            <div className="md:w-1/2 bg-brand-800 p-12 relative">
              <div className="absolute top-0 left-0 w-32 h-32 bg-brand-700 rounded-br-full opacity-50"></div>
              <div className="absolute bottom-0 right-0 w-48 h-48 bg-brand-600 rounded-tl-full opacity-30"></div>

              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full mb-6">
                  <Shield size={16} className="text-white" />
                  <span className="font-['Montserrat'] text-[12px] font-[700] text-white">USE CASE 2</span>
                </div>

                <h2 className="font-['Montserrat'] text-[40px] font-[800] text-white mb-6">Data Breach Investigation</h2>

                <p className="text-white/90 font-['Montserrat'] text-[18px] leading-[28px] mb-8">
                  Comprehensive investigation of data breaches, including malware analysis, network forensics, and recovery of compromised information with full chain of custody documentation.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                    <h3 className="font-['Montserrat'] text-[18px] font-[700] text-white mb-2">For Organizations</h3>
                    <p className="text-white/80 text-sm">Identify breach scope, secure compromised systems, and implement remediation strategies to prevent future incidents</p>
                  </div>

                  <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                    <h3 className="font-['Montserrat'] text-[18px] font-[700] text-white mb-2">For Legal Teams</h3>
                    <p className="text-white/80 text-sm">Receive detailed forensic reports with complete chain of custody for litigation and regulatory compliance</p>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-white/90">Advanced malware analysis</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-white/90">Network forensics and traffic analysis</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-white/90">Compromised data recovery</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:w-1/2 p-8 md:p-12 flex flex-col">
              <div className="mb-8">
                <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">How It Works</h3>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-['Montserrat'] font-bold text-brand-800">1</span>
                    </div>
                    <div>
                      <h4 className="font-['Montserrat'] text-[18px] font-[600] text-default-font">Incident Response</h4>
                      <p className="text-subtext-color">Immediate containment of the breach, preservation of digital evidence, and assessment of compromised systems and data.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-['Montserrat'] font-bold text-brand-800">2</span>
                    </div>
                    <div>
                      <h4 className="font-['Montserrat'] text-[18px] font-[600] text-default-font">Deep Analysis</h4>
                      <p className="text-subtext-color">Forensic examination of affected systems, malware reverse engineering, and identification of attack vectors and perpetrators.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-['Montserrat'] font-bold text-brand-800">3</span>
                    </div>
                    <div>
                      <h4 className="font-['Montserrat'] text-[18px] font-[600] text-default-font">Report & Recovery</h4>
                      <p className="text-subtext-color">Comprehensive forensic report with evidence chain of custody, remediation recommendations, and assistance with legal proceedings.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-auto">
                <div className="bg-neutral-50 rounded-xl p-6 border border-neutral-100">
                  <h4 className="font-['Montserrat'] text-[16px] font-[700] text-default-font mb-2">Real-World Example</h4>
                  <p className="text-subtext-color mb-4">
                    A financial institution in Noida suffers a ransomware attack compromising customer data. Our forensic team identifies the breach source, recovers encrypted files, provides court-admissible evidence, and helps implement security measures to prevent future incidents.
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-green-50 rounded-full text-xs font-medium text-green-700">DATA RECOVERED</span>
                    <span className="px-3 py-1 bg-green-50 rounded-full text-xs font-medium text-green-700">EVIDENCE SECURED</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div id="about-section" className="flex w-full flex-col items-center justify-center gap-16 bg-neutral-100 px-6 py-32 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        </div>

        <div className="flex w-full max-w-[1280px] flex-col items-center gap-6 z-10">
          <span className="inline-block px-4 py-1 bg-brand-50 rounded-full">
            <span className="font-['Montserrat'] text-[12px] font-[700] text-brand-800">OUR PROCESS</span>
          </span>
          <span className="w-full max-w-[768px] font-['Montserrat'] text-[48px] font-[800] leading-[52px] text-default-font text-center -tracking-[0.02em]">
            Forensic Investigation Workflow
          </span>
          <p className="max-w-[768px] text-center text-subtext-color font-['Montserrat'] text-[18px] leading-[28px]">
            Our systematic approach ensures thorough investigation, evidence preservation, and court-admissible reporting for all digital forensics cases
          </p>
        </div>

        {/* Cybercrime Investigation Flow */}
        <div className="w-full max-w-[1280px] z-10">
          <div className="flex flex-col gap-12">
            <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl">
              <div className="flex flex-col gap-8">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-brand-900 flex items-center justify-center flex-shrink-0">
                    <Shield size={32} className="text-white" />
                  </div>
                  <div>
                    <span className="inline-block px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800 mb-2">WORKFLOW 1</span>
                    <h2 className="font-['Montserrat'] text-[32px] font-[800] text-brand-900">Evidence Collection Process</h2>
                  </div>
                </div>

                <div className="relative">
                  {/* Timeline Line */}
                  <div className="absolute left-4 top-6 bottom-6 w-1 bg-brand-100"></div>

                  <div className="space-y-12 relative">
                    {/* Step 1 */}
                    <div className="flex gap-8">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-brand-900 flex items-center justify-center z-10 relative">
                          <span className="text-white font-bold">1</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-neutral-50 rounded-xl p-6 border border-neutral-100 shadow-sm">
                        <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">Evidence Identification</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="col-span-2">
                            <p className="text-subtext-color mb-4">
                              Our forensic experts identify all potential sources of digital evidence including computers, mobile devices, servers, cloud storage, and network logs. We document the scene and create a detailed evidence inventory.
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">DEVICE INVENTORY</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">SCENE DOCUMENTATION</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">CHAIN OF CUSTODY</span>
                            </div>
                          </div>
                          <div className="bg-white rounded-lg p-4 shadow-inner border border-neutral-100">
                            <h4 className="font-['Montserrat'] text-[16px] font-[600] text-default-font mb-2">Evidence Sources</h4>
                            <ul className="space-y-2 text-sm text-subtext-color">
                              <li>• Computers & laptops</li>
                              <li>• Mobile devices</li>
                              <li>• Network logs & servers</li>
                              <li>• Cloud storage</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Step 2 */}
                    <div className="flex gap-8">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-brand-900 flex items-center justify-center z-10 relative">
                          <span className="text-white font-bold">2</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-neutral-50 rounded-xl p-6 border border-neutral-100 shadow-sm">
                        <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">Forensic Extraction</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="col-span-2">
                            <p className="text-subtext-color mb-4">
                              Using specialized forensic tools, we create bit-by-bit copies of all storage devices while maintaining evidence integrity. We extract deleted files, hidden data, encrypted content, and system artifacts using advanced recovery techniques.
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">BIT-BY-BIT IMAGING</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">DATA RECOVERY</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">HASH VERIFICATION</span>
                            </div>
                          </div>
                          <div className="bg-white rounded-lg p-4 shadow-inner border border-neutral-100">
                            <h4 className="font-['Montserrat'] text-[16px] font-[600] text-default-font mb-2">Extraction Methods</h4>
                            <ul className="space-y-2 text-sm text-subtext-color">
                              <li>• Write-blocked imaging</li>
                              <li>• Deleted file recovery</li>
                              <li>• Encrypted data analysis</li>
                              <li>• Memory forensics</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Step 3 */}
                    <div className="flex gap-8">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-brand-900 flex items-center justify-center z-10 relative">
                          <span className="text-white font-bold">3</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-neutral-50 rounded-xl p-6 border border-neutral-100 shadow-sm">
                        <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">Analysis & Reporting</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="col-span-2">
                            <p className="text-subtext-color mb-4">
                              Our experts analyze the extracted evidence to identify patterns, trace digital footprints, and uncover hidden relationships. We prepare comprehensive, court-admissible reports with complete documentation of findings, methodologies, and chain of custody.
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">PATTERN ANALYSIS</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">TIMELINE RECONSTRUCTION</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">COURT REPORTS</span>
                            </div>
                          </div>
                          <div className="bg-white rounded-lg p-4 shadow-inner border border-neutral-100">
                            <h4 className="font-['Montserrat'] text-[16px] font-[600] text-default-font mb-2">Report Components</h4>
                            <ul className="space-y-2 text-sm text-subtext-color">
                              <li>• Executive summary</li>
                              <li>• Technical findings</li>
                              <li>• Evidence catalog</li>
                              <li>• Chain of custody</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Data Breach Investigation Flow */}
        <div className="w-full max-w-[1280px] z-10">
          <div className="flex flex-col gap-12">
            <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl">
              <div className="flex flex-col gap-8">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-brand-800 flex items-center justify-center flex-shrink-0">
                    <Shield size={32} className="text-white" />
                  </div>
                  <div>
                    <span className="inline-block px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800 mb-2">WORKFLOW 2</span>
                    <h2 className="font-['Montserrat'] text-[32px] font-[800] text-brand-900">Malware Analysis Process</h2>
                  </div>
                </div>

                <div className="relative">
                  {/* Timeline Line */}
                  <div className="absolute left-4 top-6 bottom-6 w-1 bg-brand-100"></div>

                  <div className="space-y-12 relative">
                    {/* Step 1 */}
                    <div className="flex gap-8">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-brand-800 flex items-center justify-center z-10 relative">
                          <span className="text-white font-bold">1</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-neutral-50 rounded-xl p-6 border border-neutral-100 shadow-sm">
                        <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">Malware Isolation</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="col-span-2">
                            <p className="text-subtext-color mb-4">
                              Our team safely isolates the malware sample in a controlled environment. We extract the malicious code from infected systems while preventing further spread and document the initial infection vector and payload characteristics.
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">SAFE EXTRACTION</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">CONTAINMENT</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">DOCUMENTATION</span>
                            </div>
                          </div>
                          <div className="bg-white rounded-lg p-4 shadow-inner border border-neutral-100">
                            <h4 className="font-['Montserrat'] text-[16px] font-[600] text-default-font mb-2">Isolation Steps</h4>
                            <ul className="space-y-2 text-sm text-subtext-color">
                              <li>• Network segmentation</li>
                              <li>• Sample extraction</li>
                              <li>• Hash generation</li>
                              <li>• Behavior documentation</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Step 2 */}
                    <div className="flex gap-8">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-brand-800 flex items-center justify-center z-10 relative">
                          <span className="text-white font-bold">2</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-neutral-50 rounded-xl p-6 border border-neutral-100 shadow-sm">
                        <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">Reverse Engineering</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="col-span-2">
                            <p className="text-subtext-color mb-4">
                              Using advanced analysis tools, we reverse engineer the malware to understand its functionality, communication protocols, encryption methods, and command & control infrastructure. We identify indicators of compromise (IOCs) for detection.
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">DISASSEMBLY</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">BEHAVIOR ANALYSIS</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">IOC EXTRACTION</span>
                            </div>
                          </div>
                          <div className="bg-white rounded-lg p-4 shadow-inner border border-neutral-100">
                            <h4 className="font-['Montserrat'] text-[16px] font-[600] text-default-font mb-2">Analysis Methods</h4>
                            <ul className="space-y-2 text-sm text-subtext-color">
                              <li>• Static code analysis</li>
                              <li>• Dynamic execution</li>
                              <li>• Network traffic analysis</li>
                              <li>• Memory forensics</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Step 3 */}
                    <div className="flex gap-8">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-brand-800 flex items-center justify-center z-10 relative">
                          <span className="text-white font-bold">3</span>
                        </div>
                      </div>

                      <div className="flex-1 bg-neutral-50 rounded-xl p-6 border border-neutral-100 shadow-sm">
                        <h3 className="font-['Montserrat'] text-[24px] font-[700] text-brand-900 mb-4">Threat Intelligence</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="col-span-2">
                            <p className="text-subtext-color mb-4">
                              We compile comprehensive threat intelligence reports including malware capabilities, attack vectors, attribution indicators, and defensive recommendations. Our reports provide actionable intelligence for incident response and security hardening.
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">THREAT PROFILES</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">ATTRIBUTION</span>
                              <span className="px-3 py-1 bg-brand-50 rounded-full text-xs font-medium text-brand-800">REMEDIATION</span>
                            </div>
                          </div>
                          <div className="bg-white rounded-lg p-4 shadow-inner border border-neutral-100">
                            <h4 className="font-['Montserrat'] text-[16px] font-[600] text-default-font mb-2">Report Contents</h4>
                            <ul className="space-y-2 text-sm text-subtext-color">
                              <li>• Malware taxonomy</li>
                              <li>• TTPs (Tactics/Techniques)</li>
                              <li>• Remediation steps</li>
                              <li>• Prevention measures</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Resources Section */}
      <div className="flex w-full flex-col items-center justify-center gap-12 bg-neutral-100 px-6 py-32">
        <div className="flex w-full flex-col items-center justify-center gap-6">
          <div className="flex w-full max-w-[1280px] flex-wrap items-center justify-center gap-6 mobile:flex-col mobile:flex-wrap mobile:gap-6">
            <div className="flex min-h-[384px] min-w-[240px] max-w-[384px] grow shrink-0 basis-0 flex-col items-start justify-end gap-8 self-stretch rounded-[32px] bg-default-background px-8 py-8 mobile:min-h-[384px] mobile:w-full mobile:min-w-[240px] mobile:grow mobile:shrink-0 mobile:basis-0">
              <div className="flex w-full flex-col items-start justify-center gap-4">
                <span className="max-w-[384px] whitespace-pre-wrap font-['Montserrat'] text-[30px] font-[700] leading-[34px] text-brand-900 -tracking-[0.025em]">
                  {"Stay Informed with Enreach\n"}
                </span>
                <span className="w-full max-w-[576px] whitespace-pre-wrap font-['Montserrat'] text-[18px] font-[400] leading-[26px] text-default-font -tracking-[0.01em]">
                  {
                    "Get the latest updates on digital forensics techniques and cyber fraud investigation trends.\n"
                  }
                </span>
              </div>
            </div>
            <div className="flex min-h-[384px] min-w-[320px] max-w-[1280px] grow shrink-0 basis-0 flex-col items-start justify-end gap-8 self-stretch rounded-[32px] bg-neutral-900 px-8 py-8">
              <div className="flex w-full flex-col items-start justify-center gap-4">
                <span className="max-w-[384px] whitespace-pre-wrap font-['Montserrat'] text-[30px] font-[700] leading-[34px] text-white -tracking-[0.025em]">
                  {"Partner with Digital Forensics Experts"}
                </span>
                <span className="w-full max-w-[576px] whitespace-pre-wrap font-['Montserrat'] text-[18px] font-[400] leading-[26px] text-white -tracking-[0.01em]">
                  {
                    "Our expert team provides comprehensive digital forensics and cyber fraud investigation services for organizations of all sizes."
                  }
                </span>
              </div>
            </div>
          </div>
          <div className="flex w-full max-w-[1280px] flex-wrap items-center justify-center gap-6 mobile:flex-col mobile:flex-wrap mobile:gap-6">
            <div className="flex min-h-[384px] min-w-[240px] max-w-[384px] grow shrink-0 basis-0 flex-col items-start justify-end gap-8 self-stretch rounded-[32px] bg-default-background px-8 py-8 mobile:min-h-[384px] mobile:w-full mobile:min-w-[240px] mobile:grow mobile:shrink-0 mobile:basis-0">
              <div className="flex w-full flex-col items-start justify-center gap-4">
                <span className="max-w-[384px] whitespace-pre-wrap font-['Montserrat'] text-[30px] font-[700] leading-[34px] text-brand-900 -tracking-[0.025em]">
                  {"Trusted Digital Investigation Services"}
                </span>
                <span className="w-full max-w-[576px] whitespace-pre-wrap font-['Montserrat'] text-[18px] font-[400] leading-[26px] text-default-font -tracking-[0.01em]">
                  {
                    "Experience professional digital forensics with court-admissible evidence and comprehensive investigation reports.\n"
                  }
                </span>
              </div>
            </div>
            <div className="flex min-h-[384px] min-w-[320px] max-w-[1280px] grow shrink-0 basis-0 flex-col items-start justify-end gap-8 self-stretch rounded-[32px] bg-brand-900 px-8 py-8">
              <div className="flex w-full flex-col items-start justify-center gap-4">
                <span className="max-w-[384px] whitespace-pre-wrap font-['Montserrat'] text-[30px] font-[700] leading-[34px] text-white -tracking-[0.025em]">
                  {"Enreach Solution:\nDigital Forensics"}
                </span>
                <span className="w-full max-w-[576px] whitespace-pre-wrap font-['Montserrat'] text-[18px] font-[400] leading-[26px] text-white -tracking-[0.01em]">
                  {
                    "Discover how we help uncover digital evidence, investigate cybercrimes, and deliver justice through expert forensic analysis."
                  }
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div id="pricing-section" className="flex w-full flex-col items-center justify-center gap-6 bg-gradient-to-br from-brand-900 to-brand-800 px-6 py-32 mobile:flex relative overflow-hidden">
        {/* Background Elements */}
       <div className="absolute top-0 right-0 w-64 h-64 bg-brand-700 rounded-full opacity-20 blur-3xl"></div>
<div className="absolute bottom-0 left-0 w-96 h-96 bg-brand-800 rounded-full opacity-20 blur-3xl"></div>

<div className="flex w-full max-w-[1280px] flex-col items-center justify-center gap-8 rounded-[32px] bg-default-background px-6 pt-24 pb-16 shadow-2xl relative z-10">

  {/* ⭐ FIXED BADGE */}
  <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-brand-900 text-white px-6 py-3 rounded-full shadow-lg text-center max-w-[260px] break-words">
    <span className="font-['Montserrat'] text-[clamp(12px,2.5vw,16px)] font-[700] leading-snug">
      Need Expert Digital Forensics Services?
    </span>
  </div>

  <div className="flex w-full flex-col items-center justify-center gap-6">

    {/* ⭐ FIXED MAIN HEADING */}
    <span className="w-full max-w-[768px] font-['Montserrat'] text-center text-balance break-words font-[900] leading-tight text-brand-900
      text-[clamp(28px,7vw,64px)]">
      GET FREE CONSULTATION
    </span>

    {/* ⭐ FIXED PARAGRAPH */}
    <span className="w-full max-w-[768px] font-['Montserrat'] text-center text-[clamp(14px,3vw,18px)] leading-relaxed font-[500] text-brand-900">
      Contact our expert team today to discuss your digital forensics and cyber investigation needs. We're here to help you uncover the truth.
    </span>
  </div>

          <div className="flex flex-col md:flex-row gap-6 items-center">
            <Button
              size="large"
              variant="neutral-secondary"
              onClick={() => window.open('mailto:contact@enreachsolution.com', '_blank')}
              icon={<ArrowRight size={20} />}
              className="px-10 py-6 hover:bg-brand-50 transition-all duration-300 text-lg"
            >
              Email Us
            </Button>
          </div>

          <div className="mt-12 flex items-center gap-2 text-subtext-color">
            <Shield size={16} />
            <span className="text-sm">Client confidentiality guaranteed with highest standards of data security</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex w-full flex-col items-start">
        <EnhancedFooter />
      </div>
    </div>
  );
}

export default AlgopayLandingPage;