"use client";

import React from "react";
import * as SubframeUtils from "../utils";
import { LinkButton } from "./LinkButton";
import { IconButton } from "./IconButton";
import { Twitter, Github, Linkedin, Wallet, Mail, Globe, ArrowRight, Shield, Clock, DollarSign, Bot } from "lucide-react";

interface EnhancedFooterProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
}

const EnhancedFooter = React.forwardRef<HTMLElement, EnhancedFooterProps>(
  function EnhancedFooter(
    { className, ...otherProps }: EnhancedFooterProps,
    ref
  ) {
    return (
      <footer
        className={SubframeUtils.twClassNames(
          "w-full bg-neutral-900 text-white",
          className
        )}
        ref={ref as any}
        {...otherProps}
      >
        {/* Top Footer Section with Newsletter */}
        
        
        {/* Main Footer Content */}
        <div className="max-w-[1280px] mx-auto px-6 py-16">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
            {/* Company Info */}
            <div className="col-span-1 md:col-span-4">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-brand-700 flex items-center justify-center">
                  <Shield size={20} className="text-white" />
                </div>
                <span className="font-['Montserrat'] text-[24px] font-[800] text-white">ENREACH SOLUTION</span>
              </div>
              
              <p className="text-white/70 mb-6 text-sm">
                Expert digital forensics and cyber fraud investigation services. We specialize in investigating complex digital crimes with cutting-edge tools and court-admissible reports.
              </p>
              
              <div className="flex items-center gap-4 mb-8">
                <IconButton 
                  icon={<Twitter />} 
                  className="bg-neutral-800 hover:bg-brand-800 transition-colors"
                />
                <IconButton 
                  icon={<Github />} 
                  className="bg-neutral-800 hover:bg-brand-800 transition-colors"
                />
                <IconButton 
                  icon={<Linkedin />} 
                  className="bg-neutral-800 hover:bg-brand-800 transition-colors"
                />
              </div>
              
              <div className="flex items-center gap-2 text-white/60 text-sm">
                <Shield size={14} />
                <span>Enterprise-grade security</span>
              </div>
            </div>
            
            {/* Links Sections */}
            <div className="col-span-1 md:col-span-2">
              <h4 className="font-['Montserrat'] text-[16px] font-[700] mb-6 text-white">Services</h4>
              <div className="flex flex-col gap-3">
                <LinkButton className="text-white/70 hover:text-white">Audio Video Analysis</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Cloud Forensics</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Computer Forensics</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Cyber Fraud Investigation</LinkButton>
              </div>
            </div>
            
            <div className="col-span-1 md:col-span-2">
              <h4 className="font-['Montserrat'] text-[16px] font-[700] mb-6 text-white">Company</h4>
              <div className="flex flex-col gap-3">
                <LinkButton className="text-white/70 hover:text-white">About Us</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Our Team</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Articles</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Why Choose Us</LinkButton>
              </div>
            </div>
            
            <div className="col-span-1 md:col-span-2">
              <h4 className="font-['Montserrat'] text-[16px] font-[700] mb-6 text-white">Expertise</h4>
              <div className="flex flex-col gap-3">
                <LinkButton className="text-white/70 hover:text-white">Cybercrime Investigation</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Data Breach Analysis</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Malware Analysis</LinkButton>
                <LinkButton className="text-white/70 hover:text-white">Digital Evidence</LinkButton>
              </div>
            </div>
            
            <div className="col-span-1 md:col-span-2">
              <h4 className="font-['Montserrat'] text-[16px] font-[700] mb-6 text-white">Contact Info</h4>
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-2">
                  <Mail size={16} className="text-white/70" />
                  <LinkButton className="text-white/70 hover:text-white">contact@enreachsolution.com</LinkButton>
                </div>
                <div className="flex items-center gap-2">
                  <Globe size={16} className="text-white/70" />
                  <span className="text-white/70 text-sm">📍 Astralis Supernova, Noida</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Features Highlight */}
          <div className="mt-16 pt-12 border-t border-neutral-800">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="flex items-center gap-3">
                <Clock size={20} className="text-brand-600" />
                <span className="text-white/80 text-sm">24/7 Support Available</span>
              </div>
              <div className="flex items-center gap-3">
                <Shield size={20} className="text-brand-600" />
                <span className="text-white/80 text-sm">100% Confidentiality</span>
              </div>
              <div className="flex items-center gap-3">
                <Bot size={20} className="text-brand-600" />
                <span className="text-white/80 text-sm">Certified Professionals</span>
              </div>
              <div className="flex items-center gap-3">
                <Globe size={20} className="text-brand-600" />
                <span className="text-white/80 text-sm">Court-Admissible Reports</span>
              </div>
            </div>
          </div>
          
          {/* Bottom Section */}
          <div className="mt-16 pt-8 border-t border-neutral-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <span className="text-white/60 text-sm">© {new Date().getFullYear()} ENREACH SOLUTION. All Rights Reserved.</span>
              <div className="flex gap-6">
                <LinkButton className="text-white/60 hover:text-white text-sm">Privacy Policy</LinkButton>
                <LinkButton className="text-white/60 hover:text-white text-sm">Terms of Service</LinkButton>
              </div>
            </div>
          </div>
        </div>
      </footer>
    );
  }
);

export default EnhancedFooter;
