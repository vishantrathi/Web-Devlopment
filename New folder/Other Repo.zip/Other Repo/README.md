# Enreach Solution Landing Page

This is a modern, responsive landing page for Enreach Solution, built with React, Vite, and Tailwind CSS.

## Features
- Fully static, fast, and SEO-friendly
- Responsive design for all devices
- Easy deployment to Vercel or any static host

## Getting Started

### Local Development
```bash
npm install
npm run dev
```

### Production Build
```bash
npm run build
```

### Deploy
You can deploy the `dist/` folder to any static host, or use Vercel for one-command deployment:
```bash
npx vercel --prod
```

## Project Structure
- `src/` — React components and styles
- `public/` — Static assets
- `dist/` — Production build output

## License
MIT
